// defense.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define DEFENSE_INTERVAL 2       // tiempo entre chequeos
#define PROBABILIDAD_ATAQUE 30   // 30% de probabilidad de impactar
#define STATUS_FILE "drones_status.txt"

void revisar_drones_y_disparar();

int main() {
    printf("🛡️ Defensa antidrone activa\n");

    while (1) {
        revisar_drones_y_disparar();
        sleep(DEFENSE_INTERVAL);
    }

    return 0;
}

void revisar_drones_y_disparar() {
    FILE *fp = fopen(STATUS_FILE, "r");
    if (!fp) {
        perror("No se puede abrir drones_status.txt");
        return;
    }

    char linea[100];
    while (fgets(linea, sizeof(linea), fp)) {
        int pid, en_zona;
        if (sscanf(linea, "%d %d", &pid, &en_zona) != 2) continue;

        if (en_zona) {
            int r = rand() % 100;
            if (r < PROBABILIDAD_ATAQUE) {
                printf("💣 Defensa intenta derribar drone PID %d\n", pid);
                if (kill(pid, SIGTERM) == 0) {
                    printf("✅ Drone PID %d derribado\n", pid);
                } else {
                    perror("Error al derribar drone");
                }
            }
        }
    }

    fclose(fp);
}
