// control_center.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAX_DRONES 100

typedef struct {
    int N;   // Número de drones
    int X;   // Número de blancos
    int Y;   // Velocidad m/s
    int Z;   // Distancia para activar defensa
    int W;   // Probabilidad de ser derribado
    int Q;   // Probabilidad de perder comunicación
    int R;   // Tiempo de reintento
} Parametros;

Parametros leer_parametros(const char *archivo) {
    Parametros p;
    FILE *fp = fopen(archivo, "r");
    if (!fp) {
        perror("Error abriendo archivo de parámetros");
        exit(1);
    }
    fscanf(fp, "%d %d %d %d %d %d %d", &p.N, &p.X, &p.Y, &p.Z, &p.W, &p.Q, &p.R);
    fclose(fp);
    return p;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <archivo_parametros>\n", argv[0]);
        exit(1);
    }

    Parametros p = leer_parametros(argv[1]);
    printf("🧠 Centro de Comando iniciando simulación...\n");

    // Limpiar archivo de resultados
    system("rm -f resultados.txt");

    // Lanzar defensa
    pid_t pid_defensa = fork();
    if (pid_defensa == 0) {
        execl("./defensa", "defensa", NULL);
        perror("Error lanzando defensa");
        exit(1);
    }

    // Lanzar monitor
    pid_t pid_monitor = fork();
    if (pid_monitor == 0) {
        execl("./monitor", "monitor", NULL);
        perror("Error lanzando monitor");
        exit(1);
    }

    // Lanzar drones
    pid_t pids[MAX_DRONES];
    char args[8][10];
    snprintf(args[0], sizeof(args[0]), "%d", p.X);
    snprintf(args[1], sizeof(args[1]), "%d", p.Y);
    snprintf(args[2], sizeof(args[2]), "%d", p.Z);
    snprintf(args[3], sizeof(args[3]), "%d", p.W);
    snprintf(args[4], sizeof(args[4]), "%d", p.Q);
    snprintf(args[5], sizeof(args[5]), "%d", p.R);

    for (int i = 0; i < p.N; i++) {
        snprintf(args[6], sizeof(args[6]), "%d", i + 1); // ID del drone
        pid_t pid = fork();
        if (pid == 0) {
            execl("./drone", "drone", args[0], args[1], args[2], args[3], args[4], args[5], args[6], NULL);
            perror("Error lanzando drone");
            exit(1);
        }
        pids[i] = pid;
        usleep(500000); // Desfase entre drones
    }

    // Esperar a que terminen los drones
    for (int i = 0; i < p.N; i++) {
        waitpid(pids[i], NULL, 0);
    }

    // Terminar defensa y monitor
    kill(pid_defensa, SIGTERM);
    kill(pid_monitor, SIGTERM);

    printf("✅ Misión finalizada. Resultados disponibles en resultados.txt\n");

    return 0;
}
