// utils.h

#ifndef UTILS_H
#define UTILS_H

typedef struct {
    int N;  // número de drones
    int X;  // número de blancos
    int Y;  // velocidad del drone (m/s)
    int Z;  // distancia a la que se activan las defensas
    int W;  // % de probabilidad de derribo
    int Q;  // % de pérdida de comunicación
    int R;  // tiempo de reconexión
} Config;

int leer_configuracion(const char *filename, Config *config);

#endif
