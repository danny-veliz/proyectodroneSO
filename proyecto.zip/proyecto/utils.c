// utils.c

#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int leer_configuracion(const char *filename, Config *config) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Error al abrir config.txt");
        return -1;
    }

    char linea[128];

    while (fgets(linea, sizeof(linea), file)) {
        if (linea[0] == '#' || linea[0] == '\n') continue; // Comentarios o líneas vacías

        char *clave = strtok(linea, "=");
        char *valor = strtok(NULL, "\n");

        if (!clave || !valor) continue;

        if (strcmp(clave, "N") == 0) config->N = atoi(valor);
        else if (strcmp(clave, "X") == 0) config->X = atoi(valor);
        else if (strcmp(clave, "Y") == 0) config->Y = atoi(valor);
        else if (strcmp(clave, "Z") == 0) config->Z = atoi(valor);
        else if (strcmp(clave, "W") == 0) config->W = atoi(valor);
        else if (strcmp(clave, "Q") == 0) config->Q = atoi(valor);
        else if (strcmp(clave, "R") == 0) config->R = atoi(valor);
    }

    fclose(file);
    return 0;
}
