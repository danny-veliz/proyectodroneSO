// drone.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <string.h>

#define STATUS_SIZE 256

// Parámetros simulados (en la práctica se pasan o leen)
static double velocidad = 10.0;       // Y m/s
static double distancia_defensa = 50; // Z metros
static int prob_derribo = 30;          // W %
static int prob_perdida_com = 10;      // Q %
static int reintentos = 6;             // R segundos

volatile int destruido = 0;

void manejar_senal(int signo) {
    if (signo == SIGTERM) {
        destruido = 1;  // Señal de destrucción
    }
}

int probabilidad(int porcentaje) {
    return (rand() % 100) < porcentaje;
}

int main(int argc, char *argv[]) {
    srand(getpid() ^ time(NULL));

    // Simulación de drone con ID (opcional)
    int drone_id = (argc > 7) ? atoi(argv[7]) : 0;

    // Registra el manejador de señal SIGTERM (para ser destruido)
    signal(SIGTERM, manejar_senal);

    // Variables simuladas
    double distancia_al_blanco = 1000.0;  // distancia inicial (ejemplo)
    //int estado_comunicacion_ok = 1;
    char status[STATUS_SIZE];

    // Simula movimiento hacia blanco
    while (distancia_al_blanco > 0 && !destruido) {
        usleep(500000); // 0.5s por "paso"

        // Simula avance
        distancia_al_blanco -= velocidad * 0.5;

        // Simula defensa anti-drone si está cerca
        if (distancia_al_blanco <= distancia_defensa) {
            if (probabilidad(prob_derribo)) {
                printf("Drone %d: Fui derribado cerca del blanco!\n", drone_id);
                fflush(stdout);
                exit(1); // Terminación abrupta simulando derribo
            }
            printf("Drone %d: Fui derribado cerca del blanco!\n", drone_id);
            fflush(stdout);
            FILE *f = fopen("resultados.txt", "a");
            if (f) {
                fprintf(f, "Drone %d: Fui derribado\n", drone_id);
                fclose(f);
            }
            exit(1);

        }

        // Simula pérdida de comunicación
        if (probabilidad(prob_perdida_com)) {
            printf("Drone %d: Perdí comunicación, intentando reconectar...\n", drone_id);
            fflush(stdout);

            int intentos = 0;
            int reconectado = 0;
            while (intentos < reintentos && !reconectado) {
                sleep(reintentos / 3);
                // 50% probabilidad de respuesta OK o falla
                if (probabilidad(50)) {
                    printf("Drone %d: Comunicación restablecida (OK)\n", drone_id);
                    reconectado = 1;
                } else {
                    FILE *f = fopen("resultados.txt", "a");
                    if (f) {
                        fprintf(f, "Drone %d: Autodestrucción\n", drone_id);
                        fclose(f);
                    }
                    exit(2);

                }
                intentos++;
            }
            if (!reconectado) {
                FILE *f = fopen("resultados.txt", "a");
                if (f) {
                    fprintf(f, "Drone %d: Autodestrucción\n", drone_id);
                    fclose(f);
                }
                exit(2);

            }
        }

        // Estado normal
        snprintf(status, STATUS_SIZE, "Drone %d: Volando, distancia al blanco %.2f m\n", drone_id, distancia_al_blanco);
        write(STDOUT_FILENO, status, strlen(status));
    }

    FILE *f = fopen("resultados.txt", "a");
    if (!destruido) {
        if (f) {
            if (probabilidad(80)) {
                printf("Drone %d: Ataque exitoso, detonación en blanco\n", drone_id);
                fprintf(f, "Drone %d: Ataque exitoso\n", drone_id);
            } else {
                printf("Drone %d: Ataque fallido, detonación fuera de blanco\n", drone_id);
                fprintf(f, "Drone %d: Ataque fallido\n", drone_id);
            }
            fclose(f);
        }
    } else {
        printf("Drone %d: Fui destruido externamente (SIGTERM)\n", drone_id);
        if (f) {
            fprintf(f, "Drone %d: Destruido por señal\n", drone_id);
            fclose(f);
        }
    }


    return 0;
}


