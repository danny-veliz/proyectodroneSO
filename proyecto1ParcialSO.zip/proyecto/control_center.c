// control_center.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <limits.h>
#define MAX_DRONES 100

int main(int argc, char *argv[]) {
    if (argc != 8) {
        fprintf(stderr, "Uso: %s N X Y Z W Q R\n", argv[0]);
        return 1;
    }

    int N = atoi(argv[1]);
    int Y = atoi(argv[3]);
    int Z = atoi(argv[4]);
    int W = atoi(argv[5]);
    int Q = atoi(argv[6]);
    int R = atoi(argv[7]);



    // Validación y asignación con valores por defecto
    if (N <= 0 || N > MAX_DRONES) {
        fprintf(stderr, "⚠️ Número de drones inválido (%d), usando valor por defecto: 5\n", N);
        N = 5;
    }

    if (Y <= 0) {
        fprintf(stderr, "⚠️ Velocidad inválida (%d), usando valor por defecto: 50\n", Y);
        Y = 50;
    }
    if (Z <= 0) {
        fprintf(stderr, "⚠️ Distancia defensa inválida (%d), usando valor por defecto: 100\n", Z);
        Z = 100;
    }
    if (W < 0 || W > 100) {
        fprintf(stderr, "⚠️ Probabilidad de derribo inválida (%d), usando valor por defecto: 30\n", W);
        W = 30;
    }
    if (Q < 0 || Q > 100) {
        fprintf(stderr, "⚠️ Probabilidad de pérdida de comunicación inválida (%d), usando valor por defecto: 10\n", Q);
        Q = 10;
    }
    if (R <= 0) {
        fprintf(stderr, "⚠️ Número de reintentos inválido (%d), usando valor por defecto: 3\n", R);
        R = 3;
    }


    printf("🧠 Centro de Comando iniciando simulación...\n");
    unlink("dron_fifo");
    system("rm -f resultados.txt");

    pid_t pid_defensa = fork();
    if (pid_defensa == 0) {
        execl("./defense", "defense", NULL);
        perror("Error lanzando defensa");
        exit(1);
    }

    pid_t pids[MAX_DRONES];
    char args[7][12];

    snprintf(args[0], sizeof(args[0]), "%d", Y);
    snprintf(args[1], sizeof(args[1]), "%d", Z);
    snprintf(args[2], sizeof(args[2]), "%d", W);
    snprintf(args[3], sizeof(args[3]), "%d", Q);
    snprintf(args[4], sizeof(args[4]), "%d", R);

    for (int i = 0; i < N; i++) {
        snprintf(args[5], sizeof(args[5]), "%d", i + 1);
        pid_t pid = fork();
        if (pid == 0) {
            execl("./drone", "drone", args[0], args[1], args[2], args[3], args[4], args[5], NULL);
            perror("Error lanzando drone");
            exit(1);
        }
        pids[i] = pid;
        usleep(300000);
    }

    for (int i = 0; i < N; i++) {
        waitpid(pids[i], NULL, 0);
    }

    kill(pid_defensa, SIGTERM);
    printf("✅ Misión finalizada. Resultados disponibles en resultados.txt\n");
    return 0;
}
