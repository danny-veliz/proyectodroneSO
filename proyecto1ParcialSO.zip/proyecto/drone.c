// drone.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <string.h>

#define STATUS_SIZE 256

// Parámetros por defecto
static double velocidad = 10.0;
static double distancia_defensa = 50.0;
static int prob_derribo = 30;
static int prob_perdida_com = 10;
static int reintentos = 3;

volatile int destruido = 0;
int drone_id = 0;

void manejar_senal(int signo) {
    if (signo == SIGTERM) {
        destruido = 1;
    }
}

int probabilidad(int porcentaje) {
    return (rand() % 100) < porcentaje;
}

int main(int argc, char *argv[]) {
    srand(getpid() ^ time(NULL));

    if (argc < 6) {
        fprintf(stderr, "❌ Argumentos insuficientes (argc=%d), abortando.\n", argc);
        exit(1);
    }

    velocidad = atof(argv[1]);
    distancia_defensa = atof(argv[2]);
    prob_derribo = atoi(argv[3]);
    prob_perdida_com = atoi(argv[4]);
    reintentos = atoi(argv[5]);
    drone_id = getpid();

    signal(SIGTERM, manejar_senal);

    double distancia_al_blanco = 1000.0;
    char status[STATUS_SIZE];

    while (distancia_al_blanco > 0 && !destruido) {
        usleep(500000);
        distancia_al_blanco -= velocidad * 0.5;

        // Enviar al FIFO
        FILE *fifo = fopen("dron_fifo", "w");
        if (fifo) {
            fprintf(fifo, "%d %.2f\n", getpid(), distancia_al_blanco);
            fclose(fifo);
        }

        if (distancia_al_blanco <= distancia_defensa && probabilidad(prob_derribo)) {
            printf("Drone %d: Fui derribado cerca del blanco!\n", drone_id);
            FILE *f = fopen("resultados.txt", "a");
            if (f) {
                fprintf(f, "Drone %d: Fui derribado\n", drone_id);
                fclose(f);
            }
            exit(1);
        }

        if (probabilidad(prob_perdida_com)) {
            printf("Drone %d: Perdí comunicación, intentando reconectar...\n", drone_id);
            int intentos = 0;
            int reconectado = 0;
            while (intentos < reintentos && !reconectado) {
                sleep(reintentos / 3);
                if (probabilidad(50)) {
                    printf("Drone %d: Comunicación restablecida (OK)\n", drone_id);
                    reconectado = 1;
                } else {
                    printf("Drone %d: Falla catastrófica en intento %d\n", drone_id, intentos + 1);
                }
                intentos++;
            }
            if (!reconectado) {
                printf("Drone %d: Autodestrucción\n", drone_id);
                FILE *f = fopen("resultados.txt", "a");
                if (f) {
                    fprintf(f, "Drone %d: Autodestrucción\n", drone_id);
                    fclose(f);
                }
                exit(2);
            }
        }

        snprintf(status, STATUS_SIZE, "Drone %d: Volando, distancia al blanco %.2f m\n", drone_id, distancia_al_blanco);
        write(STDOUT_FILENO, status, strlen(status));
    }

    FILE *f = fopen("resultados.txt", "a");
    if (f) {
        if (!destruido) {
            if (probabilidad(80)) {
                printf("Drone %d: Ataque exitoso, detonación en blanco\n", drone_id);
                fprintf(f, "Drone %d: Ataque exitoso\n", drone_id);
            } else {
                printf("Drone %d: Ataque fallido, detonación fuera de blanco\n", drone_id);
                fprintf(f, "Drone %d: Ataque fallido\n", drone_id);
            }
        } else {
            printf("Drone %d: Fui destruido externamente (SIGTERM)\n", drone_id);
            fprintf(f, "Drone %d: Destruido por señal\n", drone_id);
        }
        fclose(f);
    } else {
        perror("Error abriendo resultados.txt");
    }

    return 0;
}
