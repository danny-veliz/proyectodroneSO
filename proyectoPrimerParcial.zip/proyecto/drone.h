#ifndef DRONE_H
#define DRONE_H

typedef struct {
    int id;
    double velocidad;
    double distancia_al_blanco;
    double distancia_defensa;
    int prob_derribo;
    int prob_perdida_com;
    int reintentos;
    int destruido;
} Drone;

Drone crearDrone(int id, double v, double dist_defensa, int prob_der, int prob_com, int reintentos);
void actualizarDrone(Drone *d);
int estaDestruido(Drone d);

#endif
