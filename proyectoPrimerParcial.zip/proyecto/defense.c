// defense.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <sys/stat.h>  // ← ESTA ES LA LÍNEA QUE FALTABA

int main() {
    mkfifo("dron_fifo", 0666);
    FILE *fifo = fopen("dron_fifo", "r");
    if (!fifo) {
        perror("Error abriendo dron_fifo");
        return 1;
    }

    printf("🛡️ Defensa activa y escuchando drones...\n");

    int pid;
    float distancia;
    while (fscanf(fifo, "%d %f", &pid, &distancia) == 2) {
        if (distancia <= 100.0) {
            printf("🛡️ Defensa detectó al drone %d cerca (%.2f m) ⚠️\n", pid, distancia);
        }
    }

    fclose(fifo);
    unlink("dron_fifo");
    return 0;
}
