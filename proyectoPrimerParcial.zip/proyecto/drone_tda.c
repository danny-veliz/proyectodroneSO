#include "drone.h"

Drone crearDrone(int id, double v, double dist_defensa, int prob_der, int prob_com, int reintentos) {
    Drone d;
    d.id = id;
    d.velocidad = v;
    d.distancia_al_blanco = 1000.0;
    d.distancia_defensa = dist_defensa;
    d.prob_derribo = prob_der;
    d.prob_perdida_com = prob_com;
    d.reintentos = reintentos;
    d.destruido = 0;
    return d;
}

void actualizarDrone(Drone *d) {
    d->distancia_al_blanco -= d->velocidad * 0.5;
}

int estaDestruido(Drone d) {
    return d.destruido;
}
