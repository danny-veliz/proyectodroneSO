// main.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include "utils.h"

#define DRONE_EXEC "./drone"
#define DEFENSE_EXEC "./defense"
#define MONITOR_EXEC "./monitor"

int main(int argc, char *argv[]) {
    Config config;
    if (leer_configuracion("config.txt", &config) < 0) {
        fprintf(stderr, "Fallo al leer la configuración\n");
        exit(EXIT_FAILURE);
    }

    printf("== CENTRO DE COMANDO INICIADO ==\n");
    printf("Drones: %d, Blancos: %d, Velocidad: %d m/s\n", config.N, config.X, config.Y);

    pid_t drone_pids[config.N];

    // Lanzar proceso de defensa
    pid_t defense_pid = fork();
    if (defense_pid == 0) {
        execl(DEFENSE_EXEC, DEFENSE_EXEC, NULL);
        perror("Error al lanzar proceso de defensa");
        exit(EXIT_FAILURE);
    }

    // Lanzar proceso de monitoreo
    pid_t monitor_pid = fork();
    if (monitor_pid == 0) {
        execl(MONITOR_EXEC, MONITOR_EXEC, NULL);
        perror("Error al lanzar proceso de monitor");
        exit(EXIT_FAILURE);
    }

    // Lanzar drones
    for (int i = 0; i < config.N; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            // Pasar argumentos al drone: id y archivo de config
            char id_str[10];
            snprintf(id_str, sizeof(id_str), "%d", i);
            execl(DRONE_EXEC, DRONE_EXEC, id_str, NULL);
            perror("Error al lanzar proceso drone");
            exit(EXIT_FAILURE);
        } else {
            drone_pids[i] = pid;
        }
    }

    // Esperar a todos los drones
    for (int i = 0; i < config.N; i++) {
        int status;
        waitpid(drone_pids[i], &status, 0);
    }

    // Terminar monitor y defensa
    kill(defense_pid, SIGTERM);
    kill(monitor_pid, SIGTERM);

    waitpid(defense_pid, NULL, 0);
    waitpid(monitor_pid, NULL, 0);

    printf("== SIMULACIÓN FINALIZADA ==\n");
    return 0;
}
