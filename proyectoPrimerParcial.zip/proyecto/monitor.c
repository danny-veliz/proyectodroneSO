// monitor.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>

#define RESULT_FILE "resultados.txt"
#define INTERVALO 3

void mostrar_estado();

int main() {
    printf("📡 Monitor de drones iniciado...\n");

    while (1) {
        system("clear");
        printf("🔄 Actualizando estado de drones...\n");
        mostrar_estado();
        sleep(INTERVALO);
    }

    return 0;
}

void mostrar_estado() {
    FILE *fp = fopen(RESULT_FILE, "r");
    if (!fp) {
        printf("No se pudo leer resultados aún.\n");
        return;
    }

    char linea[100];
    int ok = 0, fallo = 0, derribado = 0, autodestruido = 0;

    while (fgets(linea, sizeof(linea), fp)) {
        if (strstr(linea, "Ataque exitoso")) ok++;
        else if (strstr(linea, "Ataque fallido")) fallo++;
        else if (strstr(linea, "derribado")) derribado++;
        else if (strstr(linea, "Autodestrucción")) autodestruido++;
        printf("📝 %s", linea); // muestra estado individual
    }

    fclose(fp);

    printf("\n📊 RESUMEN:\n");
    printf("🎯 En blanco:        %d\n", ok);
    printf("❌ Fallaron blanco:  %d\n", fallo);
    printf("💥 Derribados:       %d\n", derribado);
    printf("💀 Autodestruidos:   %d\n", autodestruido);
}
